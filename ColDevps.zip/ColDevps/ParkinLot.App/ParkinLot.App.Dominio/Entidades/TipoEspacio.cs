using System;

namespace ParkinLot.App.Dominio
{
    public enum TipoEspacio
    {
        Carro,
        Moto
    }
}