using System;

namespace ParkinLot.App.Dominio
{
    public class AdministradorSistema : Persona
    {
        public string CodigoEmpleado { get; set; }
    }
}