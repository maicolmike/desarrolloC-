using System;

namespace ParkinLot.App.Dominio
{
    public class Gerente : Persona
    {
        public string CodigoEmpleado { get; set; }
    }
}