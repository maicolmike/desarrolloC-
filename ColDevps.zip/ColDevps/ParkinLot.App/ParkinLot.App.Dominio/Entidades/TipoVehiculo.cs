using System;

namespace ParkinLot.App.Dominio
{
    public enum TipoVehiculo
    {
        Carro,
        Moto
    }
}