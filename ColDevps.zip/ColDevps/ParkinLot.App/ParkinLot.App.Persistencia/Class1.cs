﻿using System;

namespace ParkinLot.App.Persistencia
{
    public class Class1
    {
    }
}
