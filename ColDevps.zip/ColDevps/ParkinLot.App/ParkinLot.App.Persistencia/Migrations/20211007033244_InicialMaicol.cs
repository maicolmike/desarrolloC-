﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ParkinLot.App.Persistencia.Migrations
{
    public partial class InicialMaicol : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
